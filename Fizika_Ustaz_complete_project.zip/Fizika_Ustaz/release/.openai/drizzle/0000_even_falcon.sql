CREATE TABLE `config` (
	`id` integer PRIMARY KEY NOT NULL,
	`owner` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `invites` (
	`code` text PRIMARY KEY NOT NULL,
	`created` integer NOT NULL,
	`used_by` text
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`sender` text NOT NULL,
	`recipient` text,
	`body` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `problems` (
	`id` text PRIMARY KEY NOT NULL,
	`author` text NOT NULL,
	`body` text NOT NULL,
	`fingerprint` text NOT NULL,
	`options` text NOT NULL,
	`answer` integer NOT NULL,
	`solution` text NOT NULL,
	`level` text NOT NULL,
	`tags` text NOT NULL,
	`status` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `problems_fingerprint_unique` ON `problems` (`fingerprint`);--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`school` text NOT NULL,
	`iin_hash` text NOT NULL,
	`role` text DEFAULT 'teacher' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `votes` (
	`id` text PRIMARY KEY NOT NULL,
	`problem` text NOT NULL,
	`reviewer` text NOT NULL,
	`approved` integer NOT NULL,
	`comment` text NOT NULL
);
