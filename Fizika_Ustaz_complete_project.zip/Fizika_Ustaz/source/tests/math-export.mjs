import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
const dir='.sites-runtime/export-tests';mkdirSync(dir,{recursive:true});
for(const name of ['rich-format','math-export','word','pdf']){let src=readFileSync('app/'+name+'.ts','utf8');for(const dep of ['rich-format','math-export'])src=src.replaceAll("'./"+dep+"'","'./"+dep+".mjs'");const js=ts.transpileModule(src,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;writeFileSync(dir+'/'+name+'.mjs',js)}
const rich=await import(pathToFileURL(process.cwd()+'/'+dir+'/rich-format.mjs'));
const word=await import(pathToFileURL(process.cwd()+'/'+dir+'/word.mjs'));
const pdf=await import(pathToFileURL(process.cwd()+'/'+dir+'/pdf.mjs'));
const formula=rich.encodeRich(['a=\\frac{F_{\\text{үйкеліс}}}{m}','v=\\sqrt{2gh+v^{2}}',"x''=12\\,\\text{м/с}^{2}"]);
assert.deepEqual(rich.decodeRich(formula),['a=\\frac{F_{\\text{үйкеліс}}}{m}','v=\\sqrt{2gh+v^{2}}',"x''=12\\,\\text{м/с}^{2}"]);
assert.ok(rich.richPlain(formula).includes('үйкеліс'));assert.ok(rich.richPlain(formula).includes('√'));assert.equal(rich.decodeRich('MATHDOC1:{}'),null);
const mml=rich.treeMathml(rich.latexTree('\\href{javascript:alert(1)}{x}'));
assert.ok(!mml.includes('javascript:'));assert.ok(!mml.includes('href='));
mkdirSync('outputs/examples',{recursive:true});
const list=[{body:rich.sampleRich,options:JSON.stringify(['2 м/с²',rich.encodeRich(['\\frac{F_{\\text{үйкеліс}}}{m}']),'6 м/с²','8 м/с²','10 м/с²']),answer:1,solution:formula}];
const blob=word.createDocx(list);const bytes=Buffer.from(await blob.arrayBuffer());writeFileSync('outputs/examples/physics_formulas.docx',bytes);
const files={};let offset=0;while(bytes.readUInt32LE(offset)===0x04034b50){const len=bytes.readUInt32LE(offset+18),n=bytes.readUInt16LE(offset+26),extra=bytes.readUInt16LE(offset+28),start=offset+30;const name=bytes.subarray(start,start+n).toString();const body=bytes.subarray(start+n+extra,start+n+extra+len);files[name]=body.toString();offset=start+n+extra+len}
const document=files['word/document.xml'];assert.ok(document.includes('<m:f>'));assert.ok(document.includes('<m:rad>'));assert.ok(document.includes('<m:sSub>'));assert.ok(document.includes('<m:sSup>'));assert.ok(document.includes('Times New Roman'));assert.ok(document.includes('w:val="28"'));assert.ok(document.includes('үйкеліс'));assert.ok(!document.includes('MATHDOC1:'));
const font=new Uint8Array(readFileSync('public/serif.ttf'));const out=await pdf.createPdf(list,font);writeFileSync('outputs/examples/physics_formulas.pdf',Buffer.from(out.output('arraybuffer')));assert.ok(out.getNumberOfPages()>=2);
console.log('PASS: rich serialization, MathML sanitization, Kazakh subscripts, fractions, roots, powers, editable Word OMML, 14 pt font settings and PDF generation.');
