import {mkdirSync,writeFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const id=process.env.CLOUDFLARE_DATABASE_ID;if(!id||!/^[0-9a-f-]{36}$/i.test(id))throw Error('Set CLOUDFLARE_DATABASE_ID to the UUID of your own new D1 database.');
if(!existsSync('dist/server/index.js'))throw Error('Run npm run build first.');
mkdirSync('outputs',{recursive:true});
const config={name:'fizika-ustaz',main:resolve('dist/server/index.js'),compatibility_date:'2026-05-15',compatibility_flags:['nodejs_compat'],assets:{directory:resolve('dist/client'),binding:'ASSETS'},d1_databases:[{binding:'DB',database_name:'fizika-ustaz',database_id:id,migrations_dir:resolve('drizzle')}],workers_dev:true,no_bundle:true,rules:[{type:'ESModule',globs:['**/*.js','**/*.mjs']}]};
writeFileSync('outputs/wrangler.selfhost.json',JSON.stringify(config,null,2));console.log('Prepared outputs/wrangler.selfhost.json. Configure server secrets, apply migrations and deploy using your own Cloudflare account.');
