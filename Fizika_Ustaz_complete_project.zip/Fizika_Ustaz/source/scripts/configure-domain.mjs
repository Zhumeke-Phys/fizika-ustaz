import {readFileSync,writeFileSync} from 'node:fs';
const value=process.argv[2];if(!value)throw Error('Usage: node scripts/configure-domain.mjs https://YOUR-OWN-DOMAIN.kz');const u=new URL(value);if(u.protocol!=='https:'||!u.hostname.includes('.')||u.pathname!=='/'||u.username||u.password||u.search||u.hash)throw Error('Provide an HTTPS origin with a complete domain. Register and verify ownership first.');
const origin=u.origin;
const p='app/layout.tsx';const s=readFileSync(p,'utf8').replace(/const origin\s*=\s*(?:'[^']*'|"[^"]*");/,`const origin=${JSON.stringify(origin)};`);writeFileSync(p,s);
writeFileSync('public/robots.txt',`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\nSitemap: ${origin}/sitemap.xml\n`);
writeFileSync('public/sitemap.xml',`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${origin}/</loc></url><url><loc>${origin}/keyboard</loc></url></urlset>\n`);
console.log('Updated canonical metadata, robots and sitemap. This does not buy a domain or configure DNS. Rebuild and redeploy.');
