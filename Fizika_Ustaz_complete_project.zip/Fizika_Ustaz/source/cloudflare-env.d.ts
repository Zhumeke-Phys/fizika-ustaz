declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    OFFICIAL_ADMIN_EMAIL?: string;
    AUTH_PEPPER?: string;
    ADMIN_SETUP_CODE?: string;
    BUCKET?: R2Bucket;
  }
}
