# Физика — operations

This is a server-backed application, not a browser-only demo. React/Vinext renders the UI; Cloudflare Workers execute the API; D1 persists profiles, problems, review votes, invitations and messages.

## Access boundaries

- `/` is a public landing page. Guests receive no member records from `/api/data`.
- Login uses the website's own username and password. Passwords use a per-account random salt, server-held pepper and PBKDF2-SHA256 (100,000 iterations). Passwords are never stored in plaintext.
- Teacher registration requires a one-use invitation issued by the official administrator.
- `/admin` requires an authenticated website session whose account matches the one-time `admin_claim`. Cookies are HttpOnly, Secure and SameSite=Lax; raw tokens are never stored in the database.
- All owner-only API actions independently check this binding. Hiding controls is not the authorization boundary.
- The first visitor cannot become the owner. Initialization requires `ADMIN_SETUP_CODE` from the server runtime configuration and atomically creates the sole admin claim. Existing owner profile IDs are preserved when initializing the new login.
- Reviewers can review submissions, but cannot issue invitation codes or appoint administrators.
- Source editing and deployment access remain controlled by the site's owner/editor permissions. Public visitors are not project editors.

## Develop and run

1. Install the locked dependencies with `npm ci` (or the supplied `scripts/install-ci.mjs` in a managed environment).
2. Configure `AUTH_PEPPER` and `ADMIN_SETUP_CODE` through the hosting runtime environment. For a local preview, keep local values in an ignored `.dev.vars` file; never commit it.
3. Run `npm run dev` in a supported local environment, or the managed Sites preview helper.
4. Run `node tests/workflow.mjs` and `npx tsc --noEmit`.
5. Run `npm run build`. `npm start` serves the built Worker locally; it does not deploy.

## Code changes and releases

- UI and form logic: `app/page.tsx`, `app/globals.css`.
- Server authorization and business rules: `app/api/data/route.ts`, `app/official.ts`, `app/site-auth.ts` and `app/api/auth/route.ts`.
- Official admin entry: `app/admin/page.tsx`.
- Word/PDF export: `app/word.ts`, `app/pdf.ts`.
- Database declarations: `db/schema.ts`; generate new migrations with `npm run db:generate`.
- Never edit already applied migrations. Back up production data before a destructive schema change.
- Check, build, commit and push the exact source, then save and deploy that version through the site's authenticated publishing workflow. A Git push alone does not deploy this project.
- Runtime environment changes require a new deployment to apply.

## Browser support

The web app works through its HTTPS URL in current Chrome, Edge, Firefox and Safari. Installation uses the browser's Add to Home Screen / Install App feature where supported; it is not an APK. In-app browsers with blocked third-party navigation or storage should use Open in external browser and complete the website account sign-in there. Internet access is required; the service worker deliberately does not cache private data.

## Independent account recovery

Signup displays a one-time recovery code. Users must save it privately. Recovery requires the username, recovery code and a new password; it rotates the recovery code and revokes all old sessions. There is no email-verification or email-reset service. Keep `AUTH_PEPPER` stable: changing it makes existing password hashes unverifiable. Keep setup credentials out of source and the browser bundle. Login and signup attempts are rate-limited using persisted per-IP and per-IP/account windows. Do not clear admin_claim to reset a password.

## Visual physics editor

The dedicated keyboard is available publicly at `/keyboard` and inside problem, answer and solution fields. Documents use the `MATHDOC1:` versioned LaTeX-line format; legacy text remains supported. MathLive runs locally from the installed package, with fonts served from public assets. Search and duplicate fingerprints normalize rich content to text. Office Math exports use native OMML, and PDF exports lay out fractions, roots and scripts as vector text. See DEPLOY_ZH.md for independent hosting and font licensing.
