# Fizika Ustaz：源码与独立部署说明

本压缩包包含网站前端、后台 API、账号密码登录、数据库迁移、物理公式键盘、Word/PDF 导出、图标、字体说明和测试。网站不要求访问者使用 ChatGPT 账号登录。

## 域名与搜索

`fizika-ustaz` 是名称，公开域名必须包含后缀，例如 `fizika-ustaz.kz` 或 `fizika-ustaz.com`。示例不代表域名已经购买，也不保证可注册。先向域名注册商确认可用性并购买，再配置 DNS 和 HTTPS。

当前网站：https://fizika-ustaz.ortaq-top.chatgpt.site

已提供首页元数据、robots.txt 和 sitemap.xml；它们允许搜索引擎发现公开首页和键盘页面。管理员、API、用户消息和题库权限仍在服务器检查。robots.txt 不是安全边界。Google/Bing 是否以及何时收录由其决定，本项目不承诺已经出现在搜索结果。

购买域名后，在项目目录运行：

    node scripts/configure-domain.mjs https://你的完整域名.kz

此命令只更新网站元数据，不会购买域名或修改 DNS。然后重新构建、部署，并在 Google Search Console / Bing Webmaster Tools 验证域名、提交 sitemap.xml。

## 本地运行

需要 Node.js 22.13+ 和 npm。在 source 目录执行：

    npm ci
    npm run build

数据库结构在 db/schema.ts，迁移在 drizzle。新本地数据库先用 Wrangler 执行迁移；不要在已有数据库上重复手动执行已应用迁移。测试使用内存数据库，不会修改真实用户数据：

    node tests/workflow.mjs
    node tests/math-export.mjs
    npx tsc --noEmit

## 部署到自己的 Cloudflare 账号（不依赖 ChatGPT 网站托管）

1. 安装依赖，使用自己的 Cloudflare 账号登录：

       npx wrangler login
       npx wrangler d1 create fizika-ustaz

2. 保存返回的 D1 database_id，并在终端环境变量设置 CLOUDFLARE_DATABASE_ID。Windows PowerShell 示例：

       $env:CLOUDFLARE_DATABASE_ID="你的数据库UUID"

   macOS/Linux 示例：

       export CLOUDFLARE_DATABASE_ID="你的数据库UUID"

3. 构建并生成自己的发布配置：

       npm run build
       node scripts/prepare-selfhost.mjs
       npx wrangler d1 migrations apply DB --remote --config outputs/wrangler.selfhost.json

4. 自行生成两个随机秘密值，并通过交互命令设置，不要写进源码：

       npx wrangler secret put AUTH_PEPPER --config outputs/wrangler.selfhost.json
       npx wrangler secret put ADMIN_SETUP_CODE --config outputs/wrangler.selfhost.json

   AUTH_PEPPER 是密码哈希的服务端秘密，建站后必须保持稳定。ADMIN_SETUP_CODE 是只给站主的首次初始化码。压缩包不包含线上秘密、真实密码、会话令牌或真实用户数据库。

5. 发布：

       npx wrangler deploy --config outputs/wrangler.selfhost.json

6. 在 Cloudflare 控制台给 Worker 绑定自己拥有的完整域名，完成 DNS 与 HTTPS；更新第一个章节中的网站域名配置并重新构建发布。首次打开 /admin，选择“Сайт иесі үшін алғашқы баптау”，使用自己设置的初始化码创建管理员账号，妥善保存恢复码。之后由管理员生成单次邀请码邀请物理教师。

以上脚本和发布产物已构建检查，但没有替你创建外部 Cloudflare 账号、购买域名或完成你账号下的独立部署。

## 修改功能

- app/PhysicsEditor.tsx：图片风格的键盘与可编辑公式。
- app/rich-format.ts：公式文档格式、MathML 和纯文本转换。
- app/math-export.ts：可编辑 Word 公式（OMML）。
- app/pdf.ts：PDF 文本、分式、根号和上下标排版。
- app/page.tsx、app/globals.css：界面及 Times New Roman 字体设置。
- app/api：账号、题目、审核和消息后台。
- app/site-auth.ts：密码哈希及安全会话。

修改代码后重新运行测试、构建和部署。普通访问者没有修改源码或发布网站的权限。

## 字体

所有界面、输入框、键帽、预览和 Word 文本指定 Times New Roman。设备没有安装时，浏览器使用 serif 后备字体。未附带未经授权的 Microsoft 字体。若需要 PDF 和所有设备严格使用同一个 Times New Roman 文件，请按 source/public/fonts/FONT_README.txt 放入有合法授权、支持哈萨克文与希腊字符的字体。当前 PDF 在没有该文件时使用附带的开源 Liberation Serif。

## 公式保存和导出

正文、选项和解题过程保存为版本化的 MATHDOC1 文档。旧纯文本题目继续兼容。Word 使用原生可编辑 OMML；PDF 保留可见分式、根号和上下标。复杂公式、极长不换行公式和不同 Word 客户端仍需人工检查打印效果。保留代码和数据库备份，更新数据库时只追加迁移。
