# Third party components

Dependencies and their exact resolved versions are recorded in package-lock.json. Install them with npm ci. Their upstream licenses continue to apply.

- MathLive 0.111.4: MIT, Arno Gourdol. Full distributed license: public/mathlive/LICENSE.txt. Upstream: https://github.com/arnog/mathlive
- The MathLive distribution includes KaTeX WOFF2 math glyph assets in public/mathlive/fonts. They remain unmodified. Upstream font project: https://github.com/KaTeX/katex-fonts
- Liberation Serif fallback: license and notices in public/font-license.txt.
- React, Vinext, Vite, Wrangler, jsPDF and other dependencies retain the licenses distributed in their packages.
- Microsoft Times New Roman font files are not included. See public/fonts/FONT_README.txt.

Project source, build outputs and editable formula examples are included. Runtime secrets, live database content, credentials and source repository access tokens are excluded.
