# Fizika Ustaz 完整网站项目

网站：https://fizika-ustaz.ortaq-top.chatgpt.site
物理键盘：https://fizika-ustaz.ortaq-top.chatgpt.site/keyboard

请先阅读 source/DEPLOY_ZH.md。

- source：完整网站源码、数据库结构与迁移、键盘、后台、独立登录、Word/PDF 导出、测试、部署脚本及字体说明。
- release：已构建的 Cloudflare Worker 和浏览器资源。单独双击这些文件不能运行后台，需要按部署说明配置数据库和服务器秘密。
- examples：从新编辑器导出的可编辑 Word 公式及 PDF 示例。
- reference：你提供的键盘参考图片。

所有文字指定 Times New Roman；缺少该字体的设备会使用 serif 后备字体。PDF 默认附带 Liberation Serif 后备字体，精确 Times New Roman 的接入方法见字体说明。

已提供搜索引擎元数据、robots.txt 和 sitemap.xml，但搜索引擎收录需要时间，尚未代为完成 Google/Bing 所有权验证或保证搜索排名。

fizika-ustaz 可以作为域名主体；完整公开域名仍需后缀。压缩包不会自动购买 fizika-ustaz.kz 或其他域名。用自己的 Cloudflare 账号和域名可脱离 ChatGPT 托管独立部署。

没有打包真实用户数据库、密码、初始化秘密或会话令牌。首次部署到自己的服务器时，请自行设置 AUTH_PEPPER、ADMIN_SETUP_CODE，按说明创建官方管理员。
